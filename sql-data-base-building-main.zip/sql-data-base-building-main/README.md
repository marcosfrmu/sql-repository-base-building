# sql-data-base-building
DATA CLEANING AND SQL QUERING PROJECT

IN THIS DOCUMENT YOU WILL FIND THE FOLLOWING FILES:

1. SQL DATA CLEANING PROJECT.ipynb file where you can find the steps we followed to acomplish the clean csv files in order to import them to SLQ Dbeaver.
2. QUESTIONS.sql file where you can find the questions and scripts used to answer the queries inside the clean data base.
3. Clean csv.rar where you can have the csv files cleant by the team.
4. Raw csv.rar where you will find the raw, unclean database csv files.
